import React from 'react';

const LandingPage: React.FC = () => {
  return (
    <div className="w-full h-screen bg-white">
      {/* This page is intentionally blank */}
    </div>
  );
};

export default LandingPage;
